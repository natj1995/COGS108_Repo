# Tutorials

These materials follow along the topics covered in COGS 108 - Data Science in Practice. 

### Requirements

All materials use Python 3.6, with the anaconda distrition, with no other dependencies. 

Note that these notebooks use some HTML tags for headers and so on that do not necessarily render properly on Github. Run the notebook locally to see how the notebooks should look. 

This repository is under active development, and is developed and maintained by [TomDonoghue](https://github.com/TomDonoghue/).
