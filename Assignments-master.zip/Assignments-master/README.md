## Assignment Schedule

Assigments are released on Monday mornings and due on Sunday nights, either one or two weeks later, as specified below:

#### A1: Setting-Up
- Released: Monday, January 15th (W2)
- Due: Sunday, January 21st (W2)

#### A2: Data Exploration
- Released: Monday, January 22nd (W3)
- Due: Sunday, February 4th @ 11:59 pm (W4)

#### A3: Data Privacy
- Released: Monday, February 5th (W5)
- Due: Sunday, February 11th @ 11:59 pm (W5)

#### A4: Data Analysis
- Released: Monday, February 12th (W6)
- Due: Sunday, February 25th @ 11:59 pm (W7)

#### A5: Name TDB
- Released: Monday, February 26th (W8) 
- Due: Sunday, March 4th @ 11:59 pm (W9)

## Project Schedule

Intermixed with this schedule is your final project.

#### Project Proposal
Due Sunday, February 18th @ 11:59 pm (W6)

#### Project Check In
Due Thursday, March 1st (W8)

#### Final Project
Due Thursday, March 22nd @ 11:59 pm (Finals Week)
